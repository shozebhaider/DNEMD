Two main folders for setting up and running the D-NEMD simulations are provided, BUILD and SIM.

The BUILD folder contains a commented jupyter notebook that helps in building and setting up a system in the CHARMM forcefield using HTMD suite. 

The second SIM folder contains the scripts for preparing the files and running the D-NEMD AMBER simulations using ACEMD and it also contains extra example files for running the simulations. There is also another README file in that folder to explain each step. 


