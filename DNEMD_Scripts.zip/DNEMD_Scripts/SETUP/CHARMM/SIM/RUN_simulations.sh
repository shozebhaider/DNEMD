./1_eq_run_loop.sh

./2_non-eq_run_loop.sh
